﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuzzFeed5
{
  class Program
  {
    static void Main(string[] args)
    {
      // setup some sql stuff
      // that can be used
      // throughout the program
      SqlConnection conn = new SqlConnection(@"Data Source=10.1.10.219;Initial Catalog=Buzzfeed-Session5;User ID=academy_admin;Password=12345");
      SqlCommand cmd;
      SqlDataReader reader;
      conn.Open();

      // Take a quiz
      // Give our name
      Console.WriteLine("What is your name?!?!?!?1?!?!");
      string name = Console.ReadLine();

      cmd = new SqlCommand($"INSERT INTO QuizUsers (Name) VALUES ('{name}');SELECT @@IDENTITY AS Id", conn);
      reader = cmd.ExecuteReader();
      // could do has rows, but we know
      // there will always be a single row
      // coming back to us, no matter what
      reader.Read();
      string userId = reader["Id"].ToString();
      reader.Close();

      // Show a list of quizzes
      // Pick a quiz to do
      cmd = new SqlCommand("SELECT * FROM Quizzes", conn);
      reader = cmd.ExecuteReader();
      if (reader.HasRows)
      {
        while (reader.Read())
        {
          Console.WriteLine(reader["Id"] + ": " + reader["Name"]);
        }
      }
      reader.Close();
      Console.WriteLine("Which quiz would you like to take?");
      string quizId = Console.ReadLine();

      // Show a question from the quiz
      // show all possible answers
      // get user's answer
      // repeat until out of questions/patience
      cmd = new SqlCommand($"SELECT Questions.QuestionText, Questions.Id, Answers.AnswerText, Answers.Id AS Cats FROM Questions JOIN Answers ON Questions.ID = Answers.QuestionId WHERE QuizId = {quizId}", conn);
      reader = cmd.ExecuteReader();
      string LastId = "";
      List<string> answer = new List<string>();

      if (reader.HasRows)
      {
        while (reader.Read())
        {
          // if i'm on a new question id
          if (LastId != reader["Id"].ToString())
          {
            // get the user's answer on the 
            // previous question
            // Don't print this the first time
            if (LastId != "")
            {
              Console.WriteLine("Please select the answer that most fits your face.");
              answer.Add(Console.ReadLine());
            }
            // write the next question
            Console.WriteLine(reader["QuestionText"]);
            LastId = reader["Id"].ToString();
          }
          // write the potential answer
          Console.WriteLine(reader["cats"] + ") " + reader["AnswerText"]);
        }
        // ask for the last user answer (the last
        // question gets written, but never hits
        // that ask above because the loop stops)
        Console.WriteLine("Give me the last answer and we'll get your results!");
        answer.Add(Console.ReadLine());
      }
      reader.Close();

      // save user answers to the db at some point in there
      foreach (string userAnswer in answer)
      {
        cmd = new SqlCommand($"INSERT INTO UserAnswers (UserId, AnswerId) VALUES ({userId}, {userAnswer})", conn);
        cmd.ExecuteNonQuery();
      }

      // when done, show which result they got
      // by getting their total points on the quiz
      cmd = new SqlCommand($"SELECT SUM([Value]) AS Total FROM UserAnswers JOIN Answers ON Answers.Id = UserAnswers.AnswerId WHERE UserId = {userId}", conn);
      reader = cmd.ExecuteReader();
      string totalPoints = "";
      if (reader.HasRows)
      {
        reader.Read();
        totalPoints = reader["Total"].ToString();
      }
      reader.Close();
      // and then picking the right result for
      // their total
      cmd = new SqlCommand($"SELECT TOP 1 * FROM Results WHERE QuizId = {quizId} AND HighestValue >= {totalPoints} ORDER BY HighestValue Asc", conn);
      reader = cmd.ExecuteReader();
      if (reader.HasRows)
      {
        reader.Read();
        Console.WriteLine("The results are in! Your results are: " + reader["Description"]);
      }
      reader.Close();
      Console.ReadLine();
    }
  }
}