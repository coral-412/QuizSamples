﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.SqlClient;

namespace QuizClone
{
  class Program
  {
    static void Main(string[] args)
    {
       SqlConnection connection = new SqlConnection(@"Data Source=10.1.10.219;Initial Catalog=Buzzfeed-Session5;User ID=academy_admin;Password=12345");
      //SqlConnection connection;
      //connection = new SqlConnection(@"Data Source=(LocalDb)\MSSQLLocalDB;AttachDbFilename=C:\Users\coral\source\repos\QuizClone\QuizClone\Database1.mdf;Integrated Security=True");
      //Entry from Make or Take quiz

      //Name your quiz and send to quiz table
      Console.WriteLine("What's the name of your quiz?");
      string quizName = Console.ReadLine();
      int QuizId = 0;

//Name a variable for the quiz ID and pass it through to the Results and Question table***
      SqlCommand nametotable = new SqlCommand($"INSERT INTO Quizzes (Name) VALUES ('{quizName}'); SELECT @@Identity AS ID", connection);
      connection.Open();
      SqlDataReader reader;
      reader = nametotable.ExecuteReader();
      if (reader.HasRows)
      {
        reader.Read();
        QuizId = Convert.ToInt32(reader["ID"]);
        reader.Close();
      }
      connection.Close();

//List Results and send to result table
      Console.WriteLine($"Let's list out the potential results of {quizName}. You can list as many as you like.");
      bool resulting = true;
      int resultCount = 0; 
      while (resulting)
      {
        Console.WriteLine("Do you want to add a result? y/n");
        string result = Console.ReadLine();
        if (result == "y")
        {
          Console.WriteLine("Please type a result: ");
          string resultInput = Console.ReadLine();

          Console.WriteLine("What is the value of that result?");
          int resultValue = Convert.ToInt32(Console.ReadLine());

          SqlCommand insertResult = new SqlCommand($"INSERT INTO Results (Description, QuizId, HighestValue) VALUES ('{resultInput}', '{QuizId}', '{resultValue}')", connection);
          connection.Open();
          insertResult.ExecuteNonQuery();
          connection.Close();
          resultCount += 1;
        }
        else if(result == "n")
        {
          resulting = false;
        }        
      }
//List questions and send to Question Table
      Console.WriteLine($"Now we'll add the questions and possible answers to {quizName}. You can list as many questions and as many answers to each question as you like.");
      bool quest = true;
      int countquest = 0;
      int QuestionId = 0;

      while (quest == true)
      {
        Console.WriteLine("Add a question? y/n");
        string questanswer = Console.ReadLine();
        if (questanswer == "y")
        {
          Console.WriteLine("Write your question here: ");
          string userquestion = Console.ReadLine();
          countquest += 1;

          SqlCommand questtotable = new SqlCommand($"INSERT INTO Questions (QuestionText, QuizId) VALUES ('{userquestion}', '{QuizId}'); SELECT @@Identity AS ID", connection);
          connection.Open();
          SqlDataReader reader2;
          reader2 = questtotable.ExecuteReader();
          if (reader2.HasRows)
          {
            reader2.Read();
            QuestionId = Convert.ToInt32(reader2["ID"]);
            reader2.Close();
          }
          connection.Close();
          
//List answers to above question and send to Answer Table
          bool answer = true;
          while (answer)
          {
            Console.WriteLine("Do you want to add an answer? y/n");

            string addAnswer = Console.ReadLine();
            if (addAnswer == "y")
            {
              Console.WriteLine("Type the answer here!");
              string answerInput = Console.ReadLine();

              Console.WriteLine("What is the value of this answer?");
              int answerValue = Convert.ToInt32(Console.ReadLine());

              SqlCommand insertAnswer = new SqlCommand($"INSERT INTO Answers (AnswerText, QuestionId, Value) VALUES ('{answerInput}', '{QuestionId}', '{answerValue}')", connection);
              connection.Open();
              insertAnswer.ExecuteNonQuery();
              connection.Close();
            }
            else if (addAnswer == "n") 
            {
              answer = false;
            }
            else
            {
              Console.WriteLine("Did not compute, try again!");
            }
          }
        }    
        if (questanswer == "n")
        {
          quest = false;
        }
      }
    }
  }
}
