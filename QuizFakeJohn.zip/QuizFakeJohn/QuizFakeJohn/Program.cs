﻿using System;
using System.Collections.Generic;
using System.Data.SqlClient;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BuzzFeed5
{
  class Program
  {
    static void SaveAnswer(int AnswerId, int UserId)
    {
      SqlConnection conn = new SqlConnection(@"Data Source=10.1.10.219;Initial Catalog=Buzzfeed-Session5;User ID=academy_admin;Password=12345");
      conn.Open();
      SqlCommand cmd = new SqlCommand($"INSERT INTO UserAnswers (AnswerId, UserId) VALUES ({AnswerId}, {UserId})", conn);
      cmd.ExecuteNonQuery();
      conn.Close();
    }

    static void Main(string[] args)
    {
      // make user

      // select quiz
      Quiz theQuiz = QuizMaker5000(12);

      foreach (Question question in theQuiz.Questions)
      {
        Console.WriteLine(question.Text);
        int counter = 1;
        foreach (Answer answer in question.Answers)
        {
          Console.WriteLine(counter + " " + answer.Text);
          counter += 1;
        }
        Console.WriteLine("What answer fits you?");
        int answerNumber = Convert.ToInt32(Console.ReadLine()) - 1;
        SaveAnswer(answerNumber, 1);
      }

      // show results

      Console.ReadLine();
    }


    static Quiz QuizMaker5000(int quizId)
    {
      Quiz myQuiz = new Quiz();

      SqlConnection conn = new SqlConnection(@"Data Source=10.1.10.219;Initial Catalog=Buzzfeed-Session5;User ID=academy_admin;Password=12345");
      conn.Open();
      SqlCommand cmd = new SqlCommand($"SELECT * FROM Quizzes WHERE Id={quizId}", conn);
      SqlDataReader reader = cmd.ExecuteReader();

      // read quiz info
      if (reader.HasRows)
      {
        reader.Read();
        myQuiz.Title = reader["Name"].ToString();
        myQuiz.Id = Convert.ToInt32(reader["Id"]);
      }
      reader.Close();

      // read questions info
      cmd = new SqlCommand($"SELECT * FROM Questions WHERE QuizID={myQuiz.Id}", conn);
      reader = cmd.ExecuteReader();
      // myQuiz.Questions = new List<Question>(); // moved to constructor
      if (reader.HasRows)
      {
        while (reader.Read())
        {
          Question tempQuestion = new Question();
          tempQuestion.Text = reader["QuestionText"].ToString();
          tempQuestion.Id = Convert.ToInt32(reader["Id"]);
          myQuiz.Questions.Add(tempQuestion);
        }
      }
      reader.Close();

      // snag those answers
      foreach (Question q in myQuiz.Questions)
      {
        cmd = new SqlCommand($"SELECT * FROM Answers WHERE QuestionId={q.Id}", conn);
        reader = cmd.ExecuteReader();
        if (reader.HasRows)
        {
          while (reader.Read())
          {
            Answer tempAnswer = new Answer();
            tempAnswer.Text = reader["AnswerText"].ToString();
            tempAnswer.Id = Convert.ToInt32(reader["Id"]);
            tempAnswer.Value = Convert.ToInt32(reader["Value"]);
            q.Answers.Add(tempAnswer);
          }
        }
        reader.Close();
      }

      // all done reading in the quiz
      // I think
      // Let's see
      conn.Close();
      return myQuiz;

    }
  }

  class Quiz
  {
    public List<Question> Questions;
    public string Title;
    public int Id;

    public Quiz()
    {
      Questions = new List<Question>();
      Title = "";
      Id = 0;
    }
  }

  class Question
  {
    public int Id;
    public string Text;
    public List<Answer> Answers;

    public Question()
    {
      Answers = new List<Answer>();
    }
  }

  class Answer
  {
    public int Id;
    public string Text;
    public int Value;
  }


}